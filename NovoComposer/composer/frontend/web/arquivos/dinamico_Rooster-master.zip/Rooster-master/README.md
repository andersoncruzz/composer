# Rooster
Simple android smack xmpp chat client to show the usage of smack.

## Supports

* Connecting to the Server
* Sending and receiving messages
* Features a good looking chat activity

## Building

* Simply open the project in Android Studio and run the app.

##Screenshot
![screenshots](http://www.blikoon.com/wp-content/uploads/2016/04/rooster_full_chat_processed.png)

## More
here:http://www.blikoon.com/tutorials/android-smack-xmpp-introductionbuilding-a-simple-client

## License
Open Source Apache


